# Brief description about Network Shares

 In computing, a shared resource, or network share, is a computer resource made available from one host 
to other hosts on a computer network.It is a device or piece of information on a computer that can be remotely
accessed from another computer, typically via a local area network or an enterprise intranet, transparently as if 
it were a resource in the local machine. Network sharing is made possible by inter-process communication over the network.
Some examples of shareable resources are computer programs, data, storage devices, and printers. E.g. shared file access
(also known as disk sharing and folder sharing), shared printer access, shared scanner access, etc. The shared resource
is called a shared disk, shared folder or shared document.


# Our project (Samba Network Shares)
 
 Here, we want to establish a network access and share center between multiple platforms such as raspbian on raspberry pi 3,
 Windows and Linux. In that way, all three platforms can connect to the server on the network and share files.
 
 Unlike windows network sharing center which makes it easy to share files between PC's running on windows platforms, it is almost 
 impossible to share and access files from machines running on different platforms apart from FTP connection. This is the problem that our project seeks to solve.

 This type of connection will be beneficial to any user who works on multiple platforms to be able to access and share files as he navigates through 
 those platforms.

 The Samba Network Access Centre uses SMP technology for displaying files on windows using a protocol called smb.conf 
 The smb.conf apart from allowing file access and sharing also allows for files to be printed. 

 
 